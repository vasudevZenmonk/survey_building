export enum outboxMessageStatusEnum {
  PENDING = 'pending',
  SENT = 'sent',
}
