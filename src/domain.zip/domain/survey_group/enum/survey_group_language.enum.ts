export enum surveyGroupLanguageEnum {
    es_ES='es_ES',
    pt_PT='pt_PT',
    pt_BR='pt_BR',
    en_US='en_US'

}