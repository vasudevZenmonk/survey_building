export enum surveyGroupOptionEnum {
    IN_PERSON= 'in_person',
    VIRTUAL= 'virtual',
    HYBRID= 'hybrid'
}