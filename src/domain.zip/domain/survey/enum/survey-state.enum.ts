export enum surveyStateEnum {
  IN_CONSTRUCTION = 'in_construction',
  PUBLISHED = 'published',
  DEACTIVATED = 'deactivated',
}
