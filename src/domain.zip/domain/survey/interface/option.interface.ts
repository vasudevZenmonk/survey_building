export interface OptionsInterface {
  url: string;
  is_mandatory: boolean;
}
